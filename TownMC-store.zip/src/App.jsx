import React, { useState } from "react";
import { ShoppingCart, Diamond, KeyRound } from "lucide-react";
import { motion } from "framer-motion";

const PRODUCTS = [
  { id: "rank-vip", name: "VIP Rank", price: 5.99, category: "Ranks", icon: <Diamond className="w-5 h-5" /> },
  { id: "rank-mvp", name: "MVP Rank", price: 12.99, category: "Ranks", icon: <Diamond className="w-5 h-5" />, featured: true },
  { id: "rank-legend", name: "Legend Rank", price: 24.99, category: "Ranks", icon: <Diamond className="w-5 h-5" /> },
  { id: "keys-basic", name: "Basic Crate Key x5", price: 3.49, category: "Crate Keys", icon: <KeyRound className="w-5 h-5" /> },
  { id: "keys-epic", name: "Epic Crate Key x3", price: 6.99, category: "Crate Keys", icon: <KeyRound className="w-5 h-5" /> }
];

function currency(n) { return `€${n.toFixed(2)}`; }

export default function App() {
  const [view, setView] = useState("home");
  const [cart, setCart] = useState([]);

  function addToCart(product) {
    setCart([...cart, product]);
  }

  function removeFromCart(index) {
    setCart(cart.filter((_, i) => i !== index));
  }

  return (
    <div className="min-h-screen bg-gray-100 text-gray-900">
      <nav className="flex items-center justify-between bg-blue-600 p-4 text-white">
        <h1 className="text-lg font-bold">TownMC Store</h1>
        <div className="flex gap-4">
          <button onClick={() => setView("home")}>Home</button>
          <button onClick={() => setView("store")}>Store</button>
          <button onClick={() => setView("cart")}>
            <ShoppingCart className="inline w-5 h-5" /> ({cart.length})
          </button>
        </div>
      </nav>

      {view === "home" && (
        <div className="p-8 text-center">
          <h2 className="text-2xl font-bold">Welcome to TownMC</h2>
          <p className="mt-2 text-gray-700">A Minecraft survival community with a dedicated store for ranks and crate keys.</p>
        </div>
      )}

      {view === "store" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-8">
          {PRODUCTS.map((p) => (
            <motion.div key={p.id} whileHover={{ scale: 1.05 }} className="p-4 bg-white rounded shadow">
              <div className="flex items-center gap-2 mb-2">{p.icon}<h3>{p.name}</h3></div>
              <p className="text-lg">{currency(p.price)}</p>
              <button onClick={() => addToCart(p)} className="mt-2 px-3 py-1 bg-blue-600 text-white rounded">Add to Cart</button>
            </motion.div>
          ))}
        </div>
      )}

      {view === "cart" && (
        <div className="p-8">
          <h2 className="text-xl font-bold mb-4">Your Cart</h2>
          {cart.length === 0 && <p>No items in cart.</p>}
          {cart.map((item, i) => (
            <div key={i} className="flex justify-between items-center bg-white p-2 rounded shadow mb-2">
              <span>{item.name}</span>
              <span>{currency(item.price)}</span>
              <button onClick={() => removeFromCart(i)} className="text-red-600">Remove</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}